﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DividendCalculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int monthNum = 0;

        private void button1_Click(object sender, EventArgs e)
        {
            double startingMoney = Double.Parse(textBox1.Text);
            int monthMoney = (int)(startingMoney * Double.Parse(textBox2.Text) * Double.Parse(textBox3.Text));
            int endOfMonthMoney = (int)startingMoney + monthMoney;
            label5.Text = monthMoney.ToString();
            textBox1.Text = endOfMonthMoney.ToString();
            monthNum++;
            label2.Text = monthNum.ToString();
            label4.Text = ((double)monthNum / 12).ToString();
        }
    }
}
